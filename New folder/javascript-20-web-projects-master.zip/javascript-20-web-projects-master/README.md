# JavaScript 20 Web Projects

This project is based on the following Udemy course.

[JavaScript Web Projects: 20 Projects to Build Your Portfolio](https://www.udemy.com/course/javascript-web-projects-to-build-your-portfolio-resume/)
