# Joke Teller

This app needs Voice RSS API KEY.

To build it, you need to create the following file

apikey.js

```javascript
const apiKey = "YOUR API KEY";
```
